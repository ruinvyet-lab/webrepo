const fs = require('fs')

// >~~~~~~~~~~ Owner Setting ~~~~~~~~~~~< //
global.owner = "62868578778"
global.ownername = "X-Death13"
global.botname = "X-Death13"
global.footer = "X-Death13"
global.packname = "X-Death13"

// >~~~~~~~~~~ System Setting ~~~~~~~~~~~< //
global.version = "FREE VERSION 2.0"
global.idch = "120363396292293344@newsletter"
global.prefa = ["", "/"]

// >~~~~~~~~~~ Thumbnail Setting ~~~~~~~~~~~< //
global.thumb = "https://files.catbox.moe/2gzc5u.jpg"

// >~~~~~~~~~~ Message Setting ~~~~~~~~~~~< //
global.mess = {
owner: "-[ *AKSES DITOLAK* ]-\n> *_Anda Tidak Dapat Menggunakan Fitur Ini Karena Anda Bukanlah Owner!_*", 
ownerprem: "-[ *AKSES DITOLAK* ]-\n> *_Anda Tidak Dapat Menggunakan Fitur Ini Karena Anda Bukanlah Owner & User Premium!_*"
}

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //
let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})
